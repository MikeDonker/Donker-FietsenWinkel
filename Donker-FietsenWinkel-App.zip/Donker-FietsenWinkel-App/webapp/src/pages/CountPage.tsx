import { useState, useEffect } from "react";
import { Bike, Locatie, CountSession, CountResult } from "@/features/api/types";
import { bikeRepository } from "@/features/api/apiClient";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { X, Plus } from "lucide-react";

export default function CountPage() {
  const [locations, setLocations] = useState<Locatie[]>([]);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [session, setSession] = useState<CountSession | null>(null);
  const [searchBike, setSearchBike] = useState("");
  const [availableBikes, setAvailableBikes] = useState<Bike[]>([]);
  const [showDiffModal, setShowDiffModal] = useState(false);
  const [diffResult, setDiffResult] = useState<CountResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    bikeRepository.getLocations().then(setLocations);
  }, []);

  const handleStartCount = async () => {
    if (!selectedLocation) {
      toast({
        title: "Error",
        description: "Please select a location",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const newSession = await bikeRepository.startCountSession(
        selectedLocation
      );
      setSession(newSession);

      const bikes = await bikeRepository.searchBikes("", undefined, selectedLocation);
      setAvailableBikes(bikes);

      toast({
        title: "Count session started",
        description: `Session for ${selectedLocation} created`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to start session",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddBike = async (bikeId: string) => {
    if (!session) return;

    try {
      const updatedSession = await bikeRepository.addToCountSession(
        session.sessionId,
        bikeId
      );
      setSession(updatedSession);
      setSearchBike("");
      toast({
        title: "Bike added",
        description: "Bike added to count session",
      });
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to add bike",
        variant: "destructive",
      });
    }
  };

  const handleRemoveBike = (bikeId: string) => {
    if (!session) return;
    const updated = {
      ...session,
      bikes: session.bikes.filter((b) => b.id !== bikeId),
    };
    setSession(updated);
  };

  const handleFinalize = async () => {
    if (!session) return;

    setIsLoading(true);
    try {
      const result = await bikeRepository.finalizeCountSession(
        session.sessionId
      );
      setDiffResult(result);
      setShowDiffModal(true);
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to finalize count",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filteredBikes = searchBike
    ? availableBikes.filter(
        (b) =>
          (b.framnummer.toLowerCase().includes(searchBike.toLowerCase()) ||
            b.internal_sku.toLowerCase().includes(searchBike.toLowerCase())) &&
          !session?.bikes.find((sb) => sb.id === b.id)
      )
    : [];

  if (!session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-6">
        <div className="max-w-2xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 mb-2">
              Inventory Count
            </h1>
            <p className="text-slate-600">
              Start a counting session for a location
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-900">
                Select Location
              </label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose location" />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((loc) => (
                    <SelectItem key={loc.id} value={loc.naam}>
                      {loc.naam}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleStartCount}
              disabled={isLoading || !selectedLocation}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              {isLoading ? "Starting..." : "Start Count Session"}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Counting: {session.locatie}
          </h1>
          <p className="text-slate-600">
            Bikes counted: {session.bikes.length}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1 order-2 md:order-1">
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 sticky top-4">
              <h2 className="font-semibold text-slate-900 mb-4">Add Bikes</h2>
              <div className="space-y-2">
                <Input
                  type="text"
                  placeholder="Search frame number or SKU"
                  value={searchBike}
                  onChange={(e) => setSearchBike(e.target.value)}
                  className="bg-slate-50"
                />
                {searchBike && filteredBikes.length > 0 && (
                  <div className="border border-slate-200 rounded max-h-64 overflow-y-auto">
                    {filteredBikes.slice(0, 10).map((bike) => (
                      <button
                        key={bike.id}
                        onClick={() => handleAddBike(bike.id)}
                        className="w-full text-left p-2 hover:bg-slate-50 border-b border-slate-100 last:border-b-0 text-sm"
                      >
                        <p className="font-medium text-slate-900">
                          {bike.framnummer}
                        </p>
                        <p className="text-xs text-slate-600">{bike.merk} {bike.model}</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="md:col-span-2 order-1 md:order-2">
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <h2 className="font-semibold text-slate-900 mb-4">
                Counted Bikes
              </h2>
              {session.bikes.length === 0 ? (
                <p className="text-slate-600 py-8 text-center">
                  No bikes added yet
                </p>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {session.bikes.map((bike) => (
                    <div
                      key={bike.id}
                      className="flex items-center justify-between p-3 bg-slate-50 rounded border border-slate-200"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-mono font-semibold text-slate-900">
                          {bike.framnummer}
                        </p>
                        <p className="text-sm text-slate-600">
                          {bike.merk} {bike.model} • {bike.kleur}
                        </p>
                      </div>
                      <button
                        onClick={() => handleRemoveBike(bike.id)}
                        className="ml-2 p-1 hover:bg-red-100 rounded text-red-600 transition-colors"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-2 mt-6 pt-6 border-t">
                <Button
                  onClick={() => {
                    setSession(null);
                    setSelectedLocation("");
                  }}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleFinalize}
                  disabled={isLoading || session.bikes.length === 0}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {isLoading ? "Finalizing..." : "Finalize Count"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <AlertDialog open={showDiffModal} onOpenChange={setShowDiffModal}>
        <AlertDialogContent className="max-h-96 overflow-y-auto">
          <AlertDialogHeader>
            <AlertDialogTitle>Count Results</AlertDialogTitle>
            <AlertDialogDescription>
              {diffResult?.differences.length === 0
                ? "Perfect count! All bikes match."
                : `Found ${diffResult?.differences.length} discrepancies`}
            </AlertDialogDescription>
          </AlertDialogHeader>

          {diffResult && diffResult.differences.length > 0 && (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {diffResult.differences.map((diff) => (
                <div key={diff.bikeId} className="p-3 bg-red-50 rounded border border-red-200">
                  <p className="font-mono font-semibold text-slate-900">
                    {diff.framnummer}
                  </p>
                  <p className="text-sm text-red-700">
                    Expected: {diff.expected}, Counted: {diff.counted}
                  </p>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <AlertDialogCancel className="flex-1">
              Close
            </AlertDialogCancel>
            <AlertDialogAction className="flex-1 bg-blue-600 hover:bg-blue-700">
              OK
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
