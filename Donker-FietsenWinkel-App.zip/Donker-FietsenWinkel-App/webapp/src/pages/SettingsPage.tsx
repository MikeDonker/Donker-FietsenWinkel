import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/features/auth/AuthContext";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { AlertCircle } from "lucide-react";

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [debugMode, setDebugMode] = useState(false);

  useEffect(() => {
    const debug = localStorage.getItem("DEBUG_MODE") === "true";
    setDebugMode(debug);
  }, []);

  const handleDebugToggle = (checked: boolean) => {
    setDebugMode(checked);
    if (checked) {
      localStorage.setItem("DEBUG_MODE", "true");
      toast({
        title: "Debug mode enabled",
        description: "Check browser console for debug logs",
      });
    } else {
      localStorage.removeItem("DEBUG_MODE");
      toast({
        title: "Debug mode disabled",
      });
    }
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Settings</h1>
          <p className="text-slate-600">Manage your account and preferences</p>
        </div>

        <div className="space-y-4">
          {/* Account Section */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Account
            </h2>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-slate-600">Email</p>
                <p className="font-medium text-slate-900">{user?.email}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600">Name</p>
                <p className="font-medium text-slate-900">{user?.naam}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600">Role</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-2 py-1 rounded text-sm font-medium bg-blue-100 text-blue-800">
                    {user?.role === "admin" ? "Admin" : "User"}
                  </span>
                  {user?.role === "admin" && (
                    <span className="text-xs text-blue-600">
                      Full access to all features
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* API Configuration */}
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              API Configuration
            </h2>
            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded border border-slate-200">
                <p className="text-sm text-slate-600 mb-1">API Base URL</p>
                <p className="font-mono text-sm text-slate-900">
                  {import.meta.env.VITE_BACKEND_URL || "Relative URLs (default)"}
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded border border-slate-200">
                <p className="text-sm text-slate-600 mb-1">Mode</p>
                <p className="font-mono text-sm text-slate-900">Mock Adapter</p>
              </div>
            </div>
          </div>

          {/* Debug Section - Admin Only */}
          {user?.role === "admin" && (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">
                Developer Options
              </h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-900">Debug Mode</p>
                    <p className="text-sm text-slate-600">
                      Enable console logging for development
                    </p>
                  </div>
                  <Switch
                    checked={debugMode}
                    onCheckedChange={handleDebugToggle}
                  />
                </div>
              </div>
            </div>
          )}

          {/* App Info */}
          <div className="bg-blue-50 rounded-lg border border-blue-200 p-6">
            <div className="flex gap-3">
              <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-900 mb-1">App Info</h3>
                <p className="text-sm text-blue-800">
                  Bouw Scanner v1.0 • Mock Data Mode
                </p>
                <p className="text-xs text-blue-700 mt-2">
                  This is a demo app using mock data. All changes are stored
                  locally and will be lost on page refresh.
                </p>
              </div>
            </div>
          </div>

          {/* Logout Button */}
          <Button
            onClick={handleLogout}
            variant="destructive"
            className="w-full"
          >
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
}
