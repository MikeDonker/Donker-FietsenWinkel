import { useState, useEffect } from "react";
import { Bike, BikeStatus, Locatie } from "@/features/api/types";
import { bikeRepository } from "@/features/api/apiClient";
import { SearchBar } from "@/features/scanner/SearchBar";
import { FilterBar } from "@/features/scanner/FilterBar";
import { BikeCard } from "@/features/bike-card/BikeCard";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function ScannerPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [status, setStatus] = useState<BikeStatus | "" | undefined>("");
  const [locatie, setLocatie] = useState("");
  const [bikes, setBikes] = useState<Bike[]>([]);
  const [locations, setLocations] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedBike, setSelectedBike] = useState<Bike | null>(null);
  const [isBikeCardOpen, setIsBikeCardOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    bikeRepository.getLocations().then((locs: Locatie[]) => {
      setLocations(locs.map((l) => l.naam));
    });
  }, []);

  const handleSearch = async () => {
    setIsLoading(true);
    try {
      const statusParam = status ? (status as BikeStatus) : undefined;
      const results = await bikeRepository.searchBikes(
        searchQuery,
        statusParam,
        locatie
      );
      setBikes(results);
      if (results.length === 0) {
        toast({
          title: "No results",
          description: "No bikes found matching your criteria",
        });
      }
    } catch (error) {
      toast({
        title: "Search Error",
        description:
          error instanceof Error ? error.message : "Failed to search bikes",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectBike = (bike: Bike) => {
    setSelectedBike(bike);
    setIsBikeCardOpen(true);
  };

  const handleBikeAction = async () => {
    setIsBikeCardOpen(false);
    await handleSearch();
    toast({
      title: "Success",
      description: "Bike action completed successfully",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-6xl mx-auto p-4 md:p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Bike Scanner
          </h1>
          <p className="text-slate-600">Search and manage your bike inventory</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 space-y-4">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Frame number, SKU, brand, model..."
          />

          <FilterBar
            status={status ?? ""}
            onStatusChange={setStatus}
            locatie={locatie}
            onLocatieChange={setLocatie}
            locations={locations}
          />

          <Button
            onClick={handleSearch}
            disabled={isLoading}
            className="w-full md:w-auto bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Searching...
              </>
            ) : (
              "Search"
            )}
          </Button>
        </div>

        <div className="mt-6">
          {bikes.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg border border-slate-200">
              <p className="text-slate-600">
                {searchQuery || status || locatie
                  ? "No bikes found"
                  : "Enter search criteria to start"}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-sm text-slate-600 font-medium mb-4">
                Found {bikes.length} bike{bikes.length !== 1 ? "s" : ""}
              </p>
              <div className="grid gap-2">
                {bikes.map((bike) => (
                  <button
                    key={bike.id}
                    onClick={() => handleSelectBike(bike)}
                    className="text-left p-4 bg-white rounded-lg border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-semibold text-slate-900">
                          {bike.merk} {bike.model}
                        </p>
                        <p className="text-sm text-slate-600">
                          {bike.framnummer} • {bike.internal_sku}
                        </p>
                        <p className="text-xs text-slate-500 mt-1">
                          {bike.type} • {bike.kleur} • {bike.locatie}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="inline-block px-2 py-1 rounded text-xs font-medium bg-slate-100 text-slate-700">
                          {bike.status.replace("_", " ")}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <BikeCard
        bike={selectedBike}
        isOpen={isBikeCardOpen}
        onClose={() => setIsBikeCardOpen(false)}
        onAction={handleBikeAction}
      />
    </div>
  );
}
