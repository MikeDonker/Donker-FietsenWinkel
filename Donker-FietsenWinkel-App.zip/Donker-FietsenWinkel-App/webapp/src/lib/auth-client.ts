import { createAuthClient } from "better-auth/react";
import { emailOTPClient } from "better-auth/client/plugins";

export const authClient = createAuthClient({
  baseURL: import.meta.env.VITE_BACKEND_URL || undefined,
  plugins: [emailOTPClient()],
  fetchOptions: {
    credentials: "include",
  },
});

export const { useSession, signOut } = authClient;

export async function signInWithGoogle() {
  return authClient.signIn.social({
    provider: "google",
    callbackURL: import.meta.env.VITE_BASE_URL ? `${import.meta.env.VITE_BASE_URL}/` : "/",
  });
}
