import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BikeStatus } from "@/features/api/types";

interface FilterBarProps {
  status: BikeStatus | "";
  onStatusChange: (status: BikeStatus | "") => void;
  locatie: string;
  onLocatieChange: (locatie: string) => void;
  locations: string[];
}

export function FilterBar({
  status,
  onStatusChange,
  locatie,
  onLocatieChange,
  locations,
}: FilterBarProps) {
  return (
    <div className="flex gap-2">
      <Select value={status} onValueChange={(v) => onStatusChange(v as BikeStatus | "")}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="">All statuses</SelectItem>
          <SelectItem value="op_voorraad">Op voorraad</SelectItem>
          <SelectItem value="gereserveerd">Gereserveerd</SelectItem>
          <SelectItem value="verkocht">Verkocht</SelectItem>
          <SelectItem value="weg">Weg</SelectItem>
        </SelectContent>
      </Select>

      <Select value={locatie} onValueChange={onLocatieChange}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Locatie" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="">All locations</SelectItem>
          {locations.map((loc) => (
            <SelectItem key={loc} value={loc}>
              {loc}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
