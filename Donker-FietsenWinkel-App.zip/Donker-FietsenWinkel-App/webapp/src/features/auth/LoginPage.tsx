import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { authClient, signInWithGoogle } from "@/lib/auth-client";
import { AlertCircle } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isIframe, setIsIframe] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Detect if running in iframe
    setIsIframe(window.self !== window.top);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email) {
      toast({
        title: "Error",
        description: "Please enter your email",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await authClient.emailOtp.sendVerificationOtp({
        email: email.trim(),
        type: "sign-in",
      });

      if (result.error) {
        toast({
          title: "Error",
          description: result.error.message || "Failed to send code",
          variant: "destructive",
        });
      } else {
        navigate("/verify-otp", { state: { email } });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800 px-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white mb-2">Bouw Scanner</h1>
          <p className="text-slate-400">Bike inventory management system</p>
        </div>

        {isIframe && (
          <div className="bg-yellow-900/30 border border-yellow-700 rounded-lg p-3 flex gap-2">
            <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-yellow-600 font-medium">Google Sign-in unavailable</p>
              <p className="text-xs text-yellow-700">Use email login in iframe mode. Open in full window for Google Auth.</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-200">
              Email
            </label>
            <Input
              type="email"
              placeholder="user@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
            <p className="text-xs text-slate-400">
              Any email works - code sent to console
            </p>
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? "Sending code..." : "Send verification code"}
          </Button>
        </form>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-700"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-slate-900 text-slate-400">or</span>
          </div>
        </div>

        <Button
          type="button"
          disabled={isLoading || isIframe}
          onClick={async () => {
            setIsLoading(true);
            try {
              await signInWithGoogle();
            } catch (error) {
              toast({
                title: "Error",
                description: error instanceof Error ? error.message : "Google sign-in failed",
                variant: "destructive",
              });
              setIsLoading(false);
            }
          }}
          className="w-full bg-white text-slate-900 hover:bg-slate-100 font-medium"
        >
          {isLoading ? "Signing in..." : "Sign in with Google"}
        </Button>

        <div className="bg-slate-800/50 border border-slate-700 rounded p-4">
          <p className="text-xs text-slate-400">
            <strong>Demo email:</strong> test@example.com
            <br />
            <strong>OTP:</strong> Check console for verification code
          </p>
        </div>
      </div>
    </div>
  );
}
