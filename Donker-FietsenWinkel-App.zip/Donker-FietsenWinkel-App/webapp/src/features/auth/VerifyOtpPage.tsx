import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { authClient } from "@/lib/auth-client";

export default function VerifyOtpPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const email = (location.state as { email?: string })?.email || "";
  const [otp, setOtp] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!email) {
    navigate("/login", { replace: true });
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!otp || otp.length < 4) {
      toast({
        title: "Error",
        description: "Please enter a valid code",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await authClient.signIn.emailOtp({
        email: email.trim(),
        otp,
      });

      if (result.error) {
        toast({
          title: "Error",
          description: result.error.message || "Invalid code",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Success",
          description: "You are now logged in",
        });
        navigate("/scanner");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800 px-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white mb-2">Verify Code</h1>
          <p className="text-slate-400">Code sent to {email}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-200">
              Verification Code
            </label>
            <Input
              type="text"
              placeholder="000000"
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
              disabled={isLoading}
              maxLength={6}
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 text-center text-2xl font-bold tracking-widest"
            />
            <p className="text-xs text-slate-400">
              Check your browser console for the code
            </p>
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? "Verifying..." : "Verify"}
          </Button>
        </form>

        <Button
          variant="outline"
          className="w-full"
          onClick={() => navigate("/login")}
          disabled={isLoading}
        >
          Back to login
        </Button>
      </div>
    </div>
  );
}
