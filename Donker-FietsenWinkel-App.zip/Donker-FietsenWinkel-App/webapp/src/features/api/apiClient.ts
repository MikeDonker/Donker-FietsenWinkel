import { mockAdapter } from "./mockAdapter";
import {
  Bike,
  BikeStatus,
  CheckInRequest,
  CheckoutRequest,
  LoginRequest,
  LoginResponse,
  MoveRequest,
  ReserveRequest,
} from "./types";

export class BikeRepository {
  constructor(private adapter = mockAdapter) {}

  async login(req: LoginRequest): Promise<LoginResponse> {
    return this.adapter.login(req);
  }

  async getCurrentUser() {
    return this.adapter.getCurrentUser();
  }

  async searchBikes(
    query: string,
    status?: BikeStatus,
    locatie?: string
  ): Promise<Bike[]> {
    return this.adapter.searchBikes(query, status, locatie);
  }

  async getBike(id: string): Promise<Bike> {
    return this.adapter.getBike(id);
  }

  async checkIn(req: CheckInRequest): Promise<Bike> {
    return this.adapter.checkIn(req);
  }

  async move(req: MoveRequest): Promise<Bike> {
    return this.adapter.move(req);
  }

  async reserve(req: ReserveRequest): Promise<Bike> {
    return this.adapter.reserve(req);
  }

  async checkout(req: CheckoutRequest): Promise<Bike> {
    return this.adapter.checkout(req);
  }

  async getLocations() {
    return this.adapter.getLocations();
  }

  async startCountSession(locatie: string) {
    return this.adapter.startCountSession(locatie);
  }

  async addToCountSession(sessionId: string, bikeId: string) {
    return this.adapter.addToCountSession(sessionId, bikeId);
  }

  async finalizeCountSession(sessionId: string) {
    return this.adapter.finalizeCountSession(sessionId);
  }
}

export const bikeRepository = new BikeRepository();
