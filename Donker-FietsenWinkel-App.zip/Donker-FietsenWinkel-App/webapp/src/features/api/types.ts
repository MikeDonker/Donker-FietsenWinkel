import { z } from "zod";

export const BikeStatusSchema = z.enum([
  "op_voorraad",
  "gereserveerd",
  "verkocht",
  "weg",
]);
export type BikeStatus = z.infer<typeof BikeStatusSchema>;

export const BikeSchema = z.object({
  id: z.string(),
  framnummer: z.string(),
  internal_sku: z.string(),
  merk: z.string(),
  model: z.string(),
  type: z.string(),
  framemaat: z.string(),
  kleur: z.string(),
  status: BikeStatusSchema,
  locatie: z.string(),
  magazijn: z.string().optional(),
  vak: z.string().optional(),
  laatsteWijziging: z.string().datetime(),
  bewegingenLog: z.array(z.object({
    datum: z.string().datetime(),
    actie: z.string(),
    gebruiker: z.string(),
    opmerking: z.string().optional(),
  })),
});
export type Bike = z.infer<typeof BikeSchema>;

export const LocatieSchema = z.object({
  id: z.string(),
  naam: z.string(),
  magazijnen: z.array(z.object({
    id: z.string(),
    naam: z.string(),
    vakken: z.array(z.string()),
  })),
});
export type Locatie = z.infer<typeof LocatieSchema>;

export const UserSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  role: z.enum(["user", "admin"]),
  naam: z.string(),
});
export type User = z.infer<typeof UserSchema>;

export const LoginRequestSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});
export type LoginRequest = z.infer<typeof LoginRequestSchema>;

export const LoginResponseSchema = z.object({
  user: UserSchema,
  token: z.string(),
});
export type LoginResponse = z.infer<typeof LoginResponseSchema>;

export const CheckInRequestSchema = z.object({
  bikeId: z.string(),
  locatie: z.string(),
  magazijn: z.string(),
  vak: z.string(),
});
export type CheckInRequest = z.infer<typeof CheckInRequestSchema>;

export const MoveRequestSchema = z.object({
  bikeId: z.string(),
  fromLocatie: z.string(),
  toLocatie: z.string(),
  reden: z.string(),
});
export type MoveRequest = z.infer<typeof MoveRequestSchema>;

export const ReserveRequestSchema = z.object({
  bikeId: z.string(),
  verloopdatum: z.string().date(),
  notitie: z.string().optional(),
});
export type ReserveRequest = z.infer<typeof ReserveRequestSchema>;

export const CheckoutRequestSchema = z.object({
  bikeId: z.string(),
  type: z.enum(["verkocht", "weg"]),
  reden: z.string(),
  verkoopDatum: z.string().date().optional(),
  orderNummer: z.string().optional(),
});
export type CheckoutRequest = z.infer<typeof CheckoutRequestSchema>;

export const CountSessionSchema = z.object({
  sessionId: z.string(),
  locatie: z.string(),
  startedAt: z.string().datetime(),
  bikes: z.array(BikeSchema),
  finalized: z.boolean(),
});
export type CountSession = z.infer<typeof CountSessionSchema>;

export const CountResultSchema = z.object({
  sessionId: z.string(),
  locatie: z.string(),
  totalBikes: z.number(),
  differences: z.array(z.object({
    bikeId: z.string(),
    framnummer: z.string(),
    expected: z.number(),
    counted: z.number(),
  })),
});
export type CountResult = z.infer<typeof CountResultSchema>;
