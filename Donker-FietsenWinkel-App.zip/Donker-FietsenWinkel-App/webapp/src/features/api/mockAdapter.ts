import {
  Bike,
  BikeStatus,
  CheckInRequest,
  CheckoutRequest,
  CountResultSchema,
  CountSession,
  Locatie,
  LoginRequest,
  LoginResponse,
  MoveRequest,
  ReserveRequest,
  User,
} from "./types";

const MOCK_USERS: Record<string, { password: string; user: User }> = {
  "user@example.com": {
    password: "password123",
    user: {
      id: "user1",
      email: "user@example.com",
      role: "user",
      naam: "Johan Jansen",
    },
  },
  "admin@example.com": {
    password: "admin123",
    user: {
      id: "admin1",
      email: "admin@example.com",
      role: "admin",
      naam: "Admin User",
    },
  },
};

const MOCK_LOCATIONS: Locatie[] = [
  {
    id: "loc1",
    naam: "Amsterdam",
    magazijnen: [
      {
        id: "mag1",
        naam: "Magazijn A",
        vakken: ["A1", "A2", "A3", "A4", "A5"],
      },
      {
        id: "mag2",
        naam: "Magazijn B",
        vakken: ["B1", "B2", "B3", "B4"],
      },
    ],
  },
  {
    id: "loc2",
    naam: "Rotterdam",
    magazijnen: [
      {
        id: "mag3",
        naam: "Magazijn C",
        vakken: ["C1", "C2", "C3"],
      },
    ],
  },
  {
    id: "loc3",
    naam: "Utrecht",
    magazijnen: [
      {
        id: "mag4",
        naam: "Magazijn D",
        vakken: ["D1", "D2"],
      },
    ],
  },
];

const BIKE_BRANDS = ["Trek", "Giant", "Specialized", "Cannondale", "Scott"];
const BIKE_MODELS = ["FX", "Escape", "Hybrid", "Road", "Mountain"];
const BIKE_TYPES = ["MTB", "Road", "Hybrid", "BMX", "Cruiser"];
const BIKE_COLORS = ["Zwart", "Wit", "Rood", "Blauw", "Groen", "Oranje"];
const BIKE_SIZES = ["S", "M", "L", "XL", "52", "54", "56", "58"];

function generateMockBikes(): Bike[] {
  const bikes: Bike[] = [];
  const statuses: BikeStatus[] = [
    "op_voorraad",
    "gereserveerd",
    "verkocht",
    "weg",
  ];

  for (let i = 0; i < 50; i++) {
    bikes.push({
      id: `bike${i + 1}`,
      framnummer: `FRAME-${String(i + 1).padStart(6, "0")}`,
      internal_sku: `SKU-${String(i + 1).padStart(4, "0")}`,
      merk: BIKE_BRANDS[Math.floor(Math.random() * BIKE_BRANDS.length)],
      model: BIKE_MODELS[Math.floor(Math.random() * BIKE_MODELS.length)],
      type: BIKE_TYPES[Math.floor(Math.random() * BIKE_TYPES.length)],
      framemaat: BIKE_SIZES[Math.floor(Math.random() * BIKE_SIZES.length)],
      kleur: BIKE_COLORS[Math.floor(Math.random() * BIKE_COLORS.length)],
      status: statuses[Math.floor(Math.random() * statuses.length)],
      locatie: MOCK_LOCATIONS[Math.floor(Math.random() * MOCK_LOCATIONS.length)]
        .naam,
      magazijn:
        MOCK_LOCATIONS[0].magazijnen[
          Math.floor(Math.random() * MOCK_LOCATIONS[0].magazijnen.length)
        ]?.naam,
      vak: ["A1", "A2", "B1", "C1", "D1"][
        Math.floor(Math.random() * ["A1", "A2", "B1", "C1", "D1"].length)
      ],
      laatsteWijziging: new Date(
        Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000
      ).toISOString(),
      bewegingenLog: [
        {
          datum: new Date().toISOString(),
          actie: "Geënterd",
          gebruiker: "systeem",
          opmerking: "Initieel ingang",
        },
      ],
    });
  }

  return bikes;
}

const mockBikes = generateMockBikes();
const countSessions: Record<string, CountSession> = {};

export class MockAdapter {
  async login(req: LoginRequest): Promise<LoginResponse> {
    const userRecord = MOCK_USERS[req.email];
    if (!userRecord || userRecord.password !== req.password) {
      throw new Error("Invalid email or password");
    }

    return {
      user: userRecord.user,
      token: `mock-token-${userRecord.user.id}`,
    };
  }

  async getCurrentUser(): Promise<User | null> {
    const token = localStorage.getItem("token");
    if (!token) return null;
    if (token === "mock-token-user1")
      return MOCK_USERS["user@example.com"].user;
    if (token === "mock-token-admin1")
      return MOCK_USERS["admin@example.com"].user;
    return null;
  }

  async searchBikes(
    query: string,
    status?: BikeStatus,
    locatie?: string
  ): Promise<Bike[]> {
    let results = [...mockBikes];

    if (query) {
      const lowerQuery = query.toLowerCase();
      results = results.filter((bike) =>
        bike.framnummer.toLowerCase().includes(lowerQuery) ||
        bike.internal_sku.toLowerCase().includes(lowerQuery) ||
        bike.merk.toLowerCase().includes(lowerQuery) ||
        bike.model.toLowerCase().includes(lowerQuery)
      );
    }

    if (status) {
      results = results.filter((bike) => bike.status === status);
    }

    if (locatie) {
      results = results.filter((bike) => bike.locatie === locatie);
    }

    return results.slice(0, 20);
  }

  async getBike(id: string): Promise<Bike> {
    const bike = mockBikes.find((b) => b.id === id);
    if (!bike) throw new Error("Bike not found");
    return bike;
  }

  async checkIn(req: CheckInRequest): Promise<Bike> {
    const bike = mockBikes.find((b) => b.id === req.bikeId);
    if (!bike) throw new Error("Bike not found");

    bike.status = "op_voorraad";
    bike.locatie = req.locatie;
    bike.magazijn = req.magazijn;
    bike.vak = req.vak;
    bike.laatsteWijziging = new Date().toISOString();
    bike.bewegingenLog.push({
      datum: new Date().toISOString(),
      actie: "Inboeken",
      gebruiker: "user",
      opmerking: `Booked in ${req.locatie}, ${req.magazijn}, ${req.vak}`,
    });

    return bike;
  }

  async move(req: MoveRequest): Promise<Bike> {
    const bike = mockBikes.find((b) => b.id === req.bikeId);
    if (!bike) throw new Error("Bike not found");

    bike.locatie = req.toLocatie;
    bike.laatsteWijziging = new Date().toISOString();
    bike.bewegingenLog.push({
      datum: new Date().toISOString(),
      actie: "Verplaatst",
      gebruiker: "user",
      opmerking: `Moved from ${req.fromLocatie} to ${req.toLocatie}: ${req.reden}`,
    });

    return bike;
  }

  async reserve(req: ReserveRequest): Promise<Bike> {
    const bike = mockBikes.find((b) => b.id === req.bikeId);
    if (!bike) throw new Error("Bike not found");

    bike.status = "gereserveerd";
    bike.laatsteWijziging = new Date().toISOString();
    bike.bewegingenLog.push({
      datum: new Date().toISOString(),
      actie: "Gereserveerd",
      gebruiker: "user",
      opmerking: `Reserved until ${req.verloopdatum}. Notes: ${req.notitie || "None"}`,
    });

    return bike;
  }

  async checkout(req: CheckoutRequest): Promise<Bike> {
    const bike = mockBikes.find((b) => b.id === req.bikeId);
    if (!bike) throw new Error("Bike not found");

    if (req.type === "verkocht") {
      bike.status = "verkocht";
    } else if (req.type === "weg") {
      bike.status = "weg";
    }

    bike.laatsteWijziging = new Date().toISOString();
    bike.bewegingenLog.push({
      datum: new Date().toISOString(),
      actie: "Afboeken",
      gebruiker: "user",
      opmerking: `Checked out as ${req.type}: ${req.reden}. Order: ${req.orderNummer || "N/A"}`,
    });

    return bike;
  }

  async getLocations(): Promise<Locatie[]> {
    return MOCK_LOCATIONS;
  }

  async startCountSession(locatie: string): Promise<CountSession> {
    const sessionId = `session-${Date.now()}`;
    const bikes = mockBikes.filter((b) => b.locatie === locatie);

    const session: CountSession = {
      sessionId,
      locatie,
      startedAt: new Date().toISOString(),
      bikes: [],
      finalized: false,
    };

    countSessions[sessionId] = session;
    return session;
  }

  async addToCountSession(
    sessionId: string,
    bikeId: string
  ): Promise<CountSession> {
    const session = countSessions[sessionId];
    if (!session) throw new Error("Session not found");

    const bike = mockBikes.find((b) => b.id === bikeId);
    if (!bike) throw new Error("Bike not found");

    if (!session.bikes.find((b) => b.id === bikeId)) {
      session.bikes.push(bike);
    }

    return session;
  }

  async finalizeCountSession(sessionId: string) {
    const session = countSessions[sessionId];
    if (!session) throw new Error("Session not found");

    const expectedBikes = mockBikes.filter(
      (b) => b.locatie === session.locatie
    );
    const differences: Array<{
      bikeId: string;
      framnummer: string;
      expected: number;
      counted: number;
    }> = [];

    for (const expectedBike of expectedBikes) {
      const counted = session.bikes.filter((b) => b.id === expectedBike.id)
        .length;
      if (counted !== 1) {
        differences.push({
          bikeId: expectedBike.id,
          framnummer: expectedBike.framnummer,
          expected: 1,
          counted,
        });
      }
    }

    const result = {
      sessionId,
      locatie: session.locatie,
      totalBikes: session.bikes.length,
      differences,
    };

    session.finalized = true;
    return result;
  }
}

export const mockAdapter = new MockAdapter();
