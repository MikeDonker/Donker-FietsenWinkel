import { useState } from "react";
import { Bike } from "@/features/api/types";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CheckInModal,
  MoveModal,
  ReserveModal,
  CheckoutModal,
} from "../bike-card/modals";

interface BikeCardProps {
  bike: Bike | null;
  isOpen: boolean;
  onClose: () => void;
  onAction: (action: string) => void;
}

export function BikeCard({
  bike,
  isOpen,
  onClose,
  onAction,
}: BikeCardProps) {
  const [activeModal, setActiveModal] = useState<string | null>(null);

  if (!bike) return null;

  const statusColors: Record<string, string> = {
    op_voorraad: "bg-green-100 text-green-800",
    gereserveerd: "bg-yellow-100 text-yellow-800",
    verkocht: "bg-blue-100 text-blue-800",
    weg: "bg-red-100 text-red-800",
  };

  const statusLabels: Record<string, string> = {
    op_voorraad: "Op voorraad",
    gereserveerd: "Gereserveerd",
    verkocht: "Verkocht",
    weg: "Weg",
  };

  return (
    <>
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent side="right" className="w-full sm:w-96 overflow-y-auto">
          <SheetHeader>
            <SheetTitle>{bike.merk} {bike.model}</SheetTitle>
          </SheetHeader>

          <div className="mt-6 space-y-6">
            <div>
              <Badge className={statusColors[bike.status]}>
                {statusLabels[bike.status]}
              </Badge>
            </div>

            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-slate-600">Frame Number</p>
                    <p className="font-mono font-semibold">{bike.framnummer}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">SKU</p>
                    <p className="font-mono font-semibold">{bike.internal_sku}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Type</p>
                    <p className="font-semibold">{bike.type}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Frame Size</p>
                    <p className="font-semibold">{bike.framemaat}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Color</p>
                    <p className="font-semibold">{bike.kleur}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Location</p>
                    <p className="font-semibold">{bike.locatie}</p>
                  </div>
                  {bike.magazijn && (
                    <div>
                      <p className="text-sm text-slate-600">Warehouse</p>
                      <p className="font-semibold">{bike.magazijn}</p>
                    </div>
                  )}
                  {bike.vak && (
                    <div>
                      <p className="text-sm text-slate-600">Compartment</p>
                      <p className="font-semibold">{bike.vak}</p>
                    </div>
                  )}
                  <div className="col-span-2">
                    <p className="text-sm text-slate-600">Last Modified</p>
                    <p className="font-semibold">
                      {new Date(bike.laatsteWijziging).toLocaleString()}
                    </p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="history" className="mt-4">
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {bike.bewegingenLog.map((log, idx) => (
                    <div
                      key={idx}
                      className="border-l-2 border-slate-200 pl-3 pb-3"
                    >
                      <p className="text-sm font-semibold">{log.actie}</p>
                      <p className="text-xs text-slate-600">
                        {new Date(log.datum).toLocaleString()}
                      </p>
                      <p className="text-xs text-slate-600">
                        by {log.gebruiker}
                      </p>
                      {log.opmerking && (
                        <p className="text-xs text-slate-700 mt-1">
                          {log.opmerking}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <div className="space-y-2 border-t pt-4">
              <Button
                onClick={() => setActiveModal("checkin")}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Check In
              </Button>
              <Button
                onClick={() => setActiveModal("move")}
                variant="outline"
                className="w-full"
              >
                Move
              </Button>
              <Button
                onClick={() => setActiveModal("reserve")}
                variant="outline"
                className="w-full"
              >
                Reserve
              </Button>
              <Button
                onClick={() => setActiveModal("checkout")}
                variant="outline"
                className="w-full"
              >
                Check Out
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {activeModal === "checkin" && (
        <CheckInModal
          bike={bike}
          onClose={() => setActiveModal(null)}
          onSuccess={() => {
            setActiveModal(null);
            onAction("checkin");
          }}
        />
      )}
      {activeModal === "move" && (
        <MoveModal
          bike={bike}
          onClose={() => setActiveModal(null)}
          onSuccess={() => {
            setActiveModal(null);
            onAction("move");
          }}
        />
      )}
      {activeModal === "reserve" && (
        <ReserveModal
          bike={bike}
          onClose={() => setActiveModal(null)}
          onSuccess={() => {
            setActiveModal(null);
            onAction("reserve");
          }}
        />
      )}
      {activeModal === "checkout" && (
        <CheckoutModal
          bike={bike}
          onClose={() => setActiveModal(null)}
          onSuccess={() => {
            setActiveModal(null);
            onAction("checkout");
          }}
        />
      )}
    </>
  );
}
