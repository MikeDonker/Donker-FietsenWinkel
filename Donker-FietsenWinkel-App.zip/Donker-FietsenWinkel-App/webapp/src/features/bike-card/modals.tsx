import { useState, useEffect } from "react";
import { Bike, Locatie } from "@/features/api/types";
import { bikeRepository } from "@/features/api/apiClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface ModalProps {
  bike: Bike;
  onClose: () => void;
  onSuccess: () => void;
}

export function CheckInModal({ bike, onClose, onSuccess }: ModalProps) {
  const [locaties, setLocaties] = useState<Locatie[]>([]);
  const [selectedLocatie, setSelectedLocatie] = useState("");
  const [selectedMagazijn, setSelectedMagazijn] = useState("");
  const [selectedVak, setSelectedVak] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    bikeRepository.getLocations().then(setLocaties);
  }, []);

  const currentLocatie = locaties.find((l) => l.naam === selectedLocatie);
  const currentMagazijn = currentLocatie?.magazijnen.find(
    (m) => m.naam === selectedMagazijn
  );

  const handleSubmit = async () => {
    if (!selectedLocatie || !selectedMagazijn || !selectedVak) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await bikeRepository.checkIn({
        bikeId: bike.id,
        locatie: selectedLocatie,
        magazijn: selectedMagazijn,
        vak: selectedVak,
      });
      toast({
        title: "Success",
        description: "Bike checked in successfully",
      });
      onSuccess();
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to check in bike",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Check In: {bike.framnummer}</AlertDialogTitle>
          <AlertDialogDescription>
            Select location, warehouse, and compartment
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Location</label>
            <Select value={selectedLocatie} onValueChange={setSelectedLocatie}>
              <SelectTrigger>
                <SelectValue placeholder="Select location" />
              </SelectTrigger>
              <SelectContent>
                {locaties.map((loc) => (
                  <SelectItem key={loc.id} value={loc.naam}>
                    {loc.naam}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {currentLocatie && (
            <>
              <div className="space-y-2">
                <label className="text-sm font-medium">Warehouse</label>
                <Select
                  value={selectedMagazijn}
                  onValueChange={setSelectedMagazijn}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select warehouse" />
                  </SelectTrigger>
                  <SelectContent>
                    {currentLocatie.magazijnen.map((mag) => (
                      <SelectItem key={mag.id} value={mag.naam}>
                        {mag.naam}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {currentMagazijn && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Compartment</label>
                  <Select value={selectedVak} onValueChange={setSelectedVak}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select compartment" />
                    </SelectTrigger>
                    <SelectContent>
                      {currentMagazijn.vakken.map((vak) => (
                        <SelectItem key={vak} value={vak}>
                          {vak}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex gap-2">
          <AlertDialogCancel
            onClick={() => {
              setIsOpen(false);
              onClose();
            }}
          >
            Cancel
          </AlertDialogCancel>
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
            className="bg-green-600 hover:bg-green-700"
          >
            {isLoading ? "Checking in..." : "Check In"}
          </Button>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function MoveModal({ bike, onClose, onSuccess }: ModalProps) {
  const [locaties, setLocaties] = useState<Locatie[]>([]);
  const [fromLocatie, setFromLocatie] = useState(bike.locatie);
  const [toLocatie, setToLocatie] = useState("");
  const [reden, setReden] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    bikeRepository.getLocations().then(setLocaties);
  }, []);

  const handleSubmit = async () => {
    if (!toLocatie || !reden) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await bikeRepository.move({
        bikeId: bike.id,
        fromLocatie,
        toLocatie,
        reden,
      });
      toast({
        title: "Success",
        description: "Bike moved successfully",
      });
      onSuccess();
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to move bike",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Move: {bike.framnummer}</AlertDialogTitle>
          <AlertDialogDescription>
            Select destination and reason
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">From</label>
            <Input type="text" value={fromLocatie} disabled />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">To</label>
            <Select value={toLocatie} onValueChange={setToLocatie}>
              <SelectTrigger>
                <SelectValue placeholder="Select destination" />
              </SelectTrigger>
              <SelectContent>
                {locaties.map((loc) => (
                  <SelectItem key={loc.id} value={loc.naam}>
                    {loc.naam}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Reason</label>
            <Input
              type="text"
              placeholder="Enter reason for move"
              value={reden}
              onChange={(e) => setReden(e.target.value)}
              disabled={isLoading}
            />
          </div>
        </div>

        <div className="flex gap-2">
          <AlertDialogCancel
            onClick={() => {
              setIsOpen(false);
              onClose();
            }}
          >
            Cancel
          </AlertDialogCancel>
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? "Moving..." : "Move"}
          </Button>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function ReserveModal({ bike, onClose, onSuccess }: ModalProps) {
  const [verloopdatum, setVerloopdatum] = useState(
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
  );
  const [notitie, setNotitie] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(true);

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      await bikeRepository.reserve({
        bikeId: bike.id,
        verloopdatum,
        notitie: notitie || undefined,
      });
      toast({
        title: "Success",
        description: "Bike reserved successfully",
      });
      onSuccess();
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to reserve bike",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Reserve: {bike.framnummer}</AlertDialogTitle>
          <AlertDialogDescription>
            Set expiration date and optional notes
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Expiration Date</label>
            <Input
              type="date"
              value={verloopdatum}
              onChange={(e) => setVerloopdatum(e.target.value)}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Notes (optional)</label>
            <Input
              type="text"
              placeholder="Add notes..."
              value={notitie}
              onChange={(e) => setNotitie(e.target.value)}
              disabled={isLoading}
            />
          </div>
        </div>

        <div className="flex gap-2">
          <AlertDialogCancel
            onClick={() => {
              setIsOpen(false);
              onClose();
            }}
          >
            Cancel
          </AlertDialogCancel>
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
            className="bg-yellow-600 hover:bg-yellow-700"
          >
            {isLoading ? "Reserving..." : "Reserve"}
          </Button>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function CheckoutModal({ bike, onClose, onSuccess }: ModalProps) {
  const [type, setType] = useState<"verkocht" | "weg">("verkocht");
  const [reden, setReden] = useState("");
  const [verkoopDatum, setVerkoopDatum] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [orderNummer, setOrderNummer] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(true);

  const handleSubmit = async () => {
    if (!reden) {
      toast({
        title: "Error",
        description: "Please select a reason",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await bikeRepository.checkout({
        bikeId: bike.id,
        type,
        reden,
        verkoopDatum: type === "verkocht" ? verkoopDatum : undefined,
        orderNummer: orderNummer || undefined,
      });
      toast({
        title: "Success",
        description: "Bike checked out successfully",
      });
      onSuccess();
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to check out bike",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Check Out: {bike.framnummer}</AlertDialogTitle>
          <AlertDialogDescription>
            Select checkout type and reason
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Type</label>
            <Select value={type} onValueChange={(v) => setType(v as "verkocht" | "weg")}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="verkocht">Sold</SelectItem>
                <SelectItem value="weg">Lost/Removed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Reason</label>
            <Select value={reden} onValueChange={setReden}>
              <SelectTrigger>
                <SelectValue placeholder="Select reason" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="verkoop">Sale</SelectItem>
                <SelectItem value="diefstal">Theft</SelectItem>
                <SelectItem value="retour_leverancier">Supplier Return</SelectItem>
                <SelectItem value="afschrijving">Write-off</SelectItem>
                <SelectItem value="anders">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {type === "verkocht" && (
            <>
              <div className="space-y-2">
                <label className="text-sm font-medium">Sale Date</label>
                <Input
                  type="date"
                  value={verkoopDatum}
                  onChange={(e) => setVerkoopDatum(e.target.value)}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Order Number (optional)
                </label>
                <Input
                  type="text"
                  placeholder="Enter order number"
                  value={orderNummer}
                  onChange={(e) => setOrderNummer(e.target.value)}
                  disabled={isLoading}
                />
              </div>
            </>
          )}
        </div>

        <div className="flex gap-2">
          <AlertDialogCancel
            onClick={() => {
              setIsOpen(false);
              onClose();
            }}
          >
            Cancel
          </AlertDialogCancel>
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
            className="bg-red-600 hover:bg-red-700"
          >
            {isLoading ? "Checking out..." : "Check Out"}
          </Button>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}
