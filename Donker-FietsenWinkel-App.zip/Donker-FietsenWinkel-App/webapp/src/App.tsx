import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import { AuthProvider } from "@/features/auth/AuthContext";
import { PrivateRoute } from "@/features/auth/PrivateRoute";
import { useAuth } from "@/features/auth/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import LoginPage from "@/features/auth/LoginPage";
import VerifyOtpPage from "@/features/auth/VerifyOtpPage";
import ScannerPage from "./pages/ScannerPage";
import CountPage from "./pages/CountPage";
import SettingsPage from "./pages/SettingsPage";
import NotFound from "./pages/NotFound";
import { Scan, Calculator, Settings } from "lucide-react";

const queryClient = new QueryClient();

function Navigation() {
  const location = useLocation();
  const { user } = useAuth();

  if (!user || location.pathname === "/" || location.pathname === "/login" || location.pathname === "/verify-otp") {
    return null;
  }

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg md:hidden">
      <div className="flex">
        <Link
          to="/scanner"
          className={`flex-1 flex flex-col items-center justify-center py-3 px-2 ${
            isActive("/scanner")
              ? "text-blue-600 border-t-2 border-blue-600"
              : "text-slate-600"
          }`}
        >
          <Scan className="h-6 w-6 mb-1" />
          <span className="text-xs font-medium">Scanner</span>
        </Link>
        <Link
          to="/count"
          className={`flex-1 flex flex-col items-center justify-center py-3 px-2 ${
            isActive("/count")
              ? "text-blue-600 border-t-2 border-blue-600"
              : "text-slate-600"
          }`}
        >
          <Calculator className="h-6 w-6 mb-1" />
          <span className="text-xs font-medium">Count</span>
        </Link>
        {user.role === "admin" && (
          <Link
            to="/settings"
            className={`flex-1 flex flex-col items-center justify-center py-3 px-2 ${
              isActive("/settings")
                ? "text-blue-600 border-t-2 border-blue-600"
                : "text-slate-600"
            }`}
          >
            <Settings className="h-6 w-6 mb-1" />
            <span className="text-xs font-medium">Settings</span>
          </Link>
        )}
      </div>
    </nav>
  );
}

function DesktopNav() {
  const { user } = useAuth();
  const location = useLocation();

  if (!user || location.pathname === "/") {
    return null;
  }

  return (
    <nav className="hidden md:block bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-6 py-4 flex gap-6 items-center">
        <h1 className="text-xl font-bold text-slate-900">Bouw Scanner</h1>
        <div className="flex gap-4 flex-1">
          <Link
            to="/scanner"
            className={`flex items-center gap-2 px-4 py-2 rounded ${
              location.pathname === "/scanner"
                ? "bg-blue-100 text-blue-700"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Scan className="h-4 w-4" />
            Scanner
          </Link>
          <Link
            to="/count"
            className={`flex items-center gap-2 px-4 py-2 rounded ${
              location.pathname === "/count"
                ? "bg-blue-100 text-blue-700"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Calculator className="h-4 w-4" />
            Count
          </Link>
          {user.role === "admin" && (
            <Link
              to="/settings"
              className={`flex items-center gap-2 px-4 py-2 rounded ${
                location.pathname === "/settings"
                  ? "bg-blue-100 text-blue-700"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Settings className="h-4 w-4" />
              Settings
            </Link>
          )}
        </div>
        <div className="text-sm text-slate-600">
          {user.naam || user.email}
        </div>
      </div>
    </nav>
  );
}

function AppContent() {
  return (
    <div>
      <DesktopNav />
      <div className="pb-20 md:pb-0">
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/verify-otp" element={<VerifyOtpPage />} />
          <Route
            path="/scanner"
            element={
              <ProtectedRoute>
                <ScannerPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/count"
            element={
              <ProtectedRoute>
                <CountPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <SettingsPage />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
      <Navigation />
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
