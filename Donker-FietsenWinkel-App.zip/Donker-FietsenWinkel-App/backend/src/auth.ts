import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { emailOTP } from "better-auth/plugins";
import { google } from "better-auth/social-providers";
import { prisma } from "./prisma";
import { env } from "./env";

// Mock email sending for now
async function sendOTP({
  email,
  otp,
  type,
}: {
  email: string;
  otp: string;
  type: string;
}) {
  console.log(`[OTP] Type: ${type}, Email: ${email}, Code: ${otp}`);
}

const getCallbackURL = () => {
  const base = env.VITE_BASE_URL || env.BACKEND_URL || "http://localhost:8000";
  return `${base}/auth/callback/google`;
};

if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  console.log("[Auth] Google OAuth configured");
}

const baseConfig = {
  database: prismaAdapter(prisma, { provider: "sqlite" }),
  secret: env.BETTER_AUTH_SECRET,
  baseURL: env.BACKEND_URL,
  trustedOrigins: [
    "http://localhost:*",
    "http://127.0.0.1:*",
    "https://*.dev.vibecode.run",
    "https://*.vibecode.run",
    "https://*.vibecodeapp.com",
    "https://*.vibecode.dev",
    "https://vibecode.dev",
  ],
  plugins: [
    emailOTP({
      async sendVerificationOTP({ email, otp, type }) {
        if (type !== "sign-in") return;
        await sendOTP({ email, otp: String(otp), type });
      },
    }),
  ],
  advanced: {
    trustedProxyHeaders: true,
    disableCSRFCheck: true,
    defaultCookieAttributes: {
      sameSite: "None" as const,
      secure: true,
      partitioned: true,
    },
  },
};

export const auth = betterAuth({
  ...baseConfig,
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID || "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
      redirectURI: getCallbackURL(),
    },
  },
});
