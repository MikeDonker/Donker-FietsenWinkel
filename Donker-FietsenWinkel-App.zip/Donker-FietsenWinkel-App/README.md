# Bouw Scanner - Bike Shop Inventory Management

Professional web app for bike shop warehouse and counter operations. Track, search, count, and manage inventory with actions like check-in, move, reserve, and checkout.

## Quick Start

```bash
cd /home/user/workspace/webapp
bun start
```

App runs on `http://localhost:8000`

## Environment Variables

Set in Vibecode ENV tab or .env:
- `VITE_API_URL` - Backend API base URL (defaults to relative URLs for production)

## Demo Credentials

**Regular User:**
- Email: `user@example.com`
- Password: `password123`

**Admin User:**
- Email: `admin@example.com`
- Password: `admin123`

## Features

### Login Screen
- Email/password authentication
- Session persisted in localStorage
- Auto-redirect to scanner after login

### Scanner Screen
- **Search**: Frame number, internal SKU, brand name, model
- **Filters**: By status (On Stock, Reserved, In Transit, etc.) and location
- **Results**: Max 20 bikes per query, click to open bike card
- **Responsive**: Mobile-first design, works on phone/tablet

### Bike Card Panel
Shows full bike details:
- Brand, model, type, frame size, color
- Frame number, internal SKU
- Status, location, last modified
- Modified by (username)

**Actions available:**
1. **Check In** - Receive bike at location (warehouse/section/rack)
2. **Move** - Transfer between locations with reason
3. **Reserve** - Hold bike with expiry date (default +7 days)
4. **Checkout** - Sell or remove (sold, theft, return, write-off, other)

### Inventory Count Screen
- Select location to count
- Scan/select bikes one by one
- Real-time list of counted bikes
- Diff overview showing expected vs. actual
- Confirm to write corrections as movements

### Settings Screen (Admin Only)
- View account info
- Display API base URL
- Debug toggle
- Logout button

## API Integration

### Current: Mock Adapter
App includes production-ready mock adapter. All data is in-memory (resets on page refresh). No actual backend needed to demo.

### Production: Switch to Real API
Backend endpoints required:
- `POST /auth/login` - User authentication
- `GET /me` - Current user + role
- `GET /bikes?search=X&status=Y&locationId=Z` - Search/filter
- `GET /bikes/:id` - Bike details
- `PATCH /bikes/:id` - Update bike (status, location)
- `POST /inventory-movements` - Log status/location changes
- `POST /inventory/counts` - Finalize count session

To use real backend:
1. Set `VITE_API_URL` in env
2. Update `/src/features/api/apiClient.ts` to use real API instead of mock
3. API client auto-unwraps `{ data: ... }` envelope per API contract

## Architecture

```
src/
├── features/
│   ├── auth/          → Login, AuthContext, PrivateRoute
│   ├── scanner/       → Search, filters, results list
│   ├── bike-card/     → Detail panel, modals
│   ├── count/         → Count sessions
│   ├── settings/      → Admin settings
│   └── api/           → apiClient, mock adapter, types
├── pages/             → Main route pages
├── components/ui/     → shadcn/ui components
└── App.tsx            → Routes, navigation
```

## Business Rules Enforced

- **Check In**: Requires location, warehouse, rack selection
- **Move**: Requires from/to location and reason
- **Reserve**: Requires expiry date (defaults to +7 days), optional note
- **Checkout**: Requires reason (sold, theft, return, write-off, other)
  - If sold: Optional sale date, order number
- **Every action**: Logs as inventory movement
- **Auth**: 401 redirects to login, role-based access for admin screens

## PWA Support

App is PWA-installable:
- Manifest: `/manifest.json`
- Service worker: `/sw.js` (caches static assets, no offline mutations)
- Can be installed on mobile: "Add to Home Screen"
- Works best online (mutations require backend connection)

## Tech Stack

- **Framework**: Vite + React 18 + React Router v6
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS + shadcn/ui
- **Validation**: Zod schemas
- **Data**: Tanstack React Query for caching
- **Forms**: React Hook Form
- **Icons**: lucide-react
- **UI Components**: Dialog, Drawer, Tabs, Select, etc.

## Testing

1. **Login**: Use demo credentials above
2. **Search**: Type "Scott", "frame123", or "red"
3. **Action**: Click bike → Check In (set location) → Submit
4. **Count**: Scanner → Count → Select location → Click bikes → Afronden
5. **Settings**: Admin login → Settings tab (bottom)

All actions work without backend—mock data supports full flow.

## Build for Production

```bash
bun run build
```

Output in `dist/` directory. PWA-ready for hosting.

## Notes

- Mock adapter has 50 pre-generated bikes across multiple locations
- All timestamps are current UTC
- Type-safe throughout: no `any`, all Zod validated
- Responsive design tested on mobile
- Dark mode CSS variables ready (use `next-themes` if needed)
